<?
// Ambil User Agent dari config sc lama.
// Buat yang belum pernah daftar. Capture dulu ambil User Agentnya agar tidak system tidak mendetek penyalahgunaan

$UserAgent = "Mozilla/5.0 (Linux; Android 9.0.0; MI 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.93 Mobile Safari/537.36";
$Email = "rikydeangeloo@gmail.com";
$Password = "masukaja13";